# OmniFlow
**Multi-Channel Sales Intelligence & Business Analytics Platform**

OmniFlow is an academic software project designed to consolidate sales information from multiple channels and turn it into useful business insights. It focuses on analytics and reporting rather than replacing an existing store's inventory or order-management system.

## Initial stack
- PHP
- MySQL
- HTML5 / CSS3 / JavaScript
- Bootstrap 5 (CDN)
- Chart.js (CDN)

## Current starter features
- Dashboard layout
- KPI cards with sample figures
- Sales performance chart with sample data
- Recent sales table
- Navigation for Sales, Analytics and Reports

> The current dashboard uses demonstration data. It is not connected to a live store or database yet.

## Run locally
1. Install XAMPP, WAMP, or another PHP development environment.
2. Copy the `omniflow` folder into your web server's document root (for XAMPP, `htdocs`).
3. Start Apache.
4. Visit `http://localhost/omniflow/`.

## Project structure
```text
omniflow/
├── index.php
├── config/
│   └── database.php
├── database/
│   └── omniflow.sql
├── includes/
│   ├── header.php
│   ├── sidebar.php
│   └── footer.php
├── pages/
│   ├── dashboard.php
│   ├── sales.php
│   ├── analytics.php
│   └── reports.php
└── assets/
    ├── css/style.css
    └── js/script.js
```

## Team workflow
- Create a separate branch for each feature.
- Commit small, meaningful changes.
- Open a Pull Request before merging into `main`.
- Do not commit database passwords, API keys, or other secrets.

## Planned development
1. Finalize requirements and database design.
2. Build authentication and role permissions.
3. Add sales-channel data import (CSV/Excel).
4. Store normalized sales records in MySQL.
5. Build channel, product, and time-period analytics.
6. Add report filters and export options.
