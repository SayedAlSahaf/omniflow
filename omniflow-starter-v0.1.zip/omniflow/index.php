<?php
// OmniFlow application entry point.
$page = $_GET['page'] ?? 'dashboard';
$allowedPages = ['dashboard', 'sales', 'analytics', 'reports'];
if (!in_array($page, $allowedPages, true)) {
    http_response_code(404);
    $page = 'dashboard';
}
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>
<main class="main-content">
    <?php require __DIR__ . "/pages/{$page}.php"; ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
