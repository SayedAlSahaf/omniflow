<?php
/**
 * PDO database connection.
 * Update these values for your local MySQL environment.
 * Never commit real production credentials.
 */
$host = 'localhost';
$dbname = 'omniflow';
$username = 'root';
$password = '';

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $exception) {
    // Avoid exposing credentials or internal errors to visitors.
    error_log($exception->getMessage());
    http_response_code(500);
    exit('Database connection failed. Check config/database.php and MySQL.');
}
