<aside class="sidebar">
    <a class="brand" href="index.php"><span class="brand-mark">O</span> OmniFlow</a>
    <p class="nav-caption">WORKSPACE</p>
    <nav class="nav flex-column">
        <a class="nav-link <?= $page === 'dashboard' ? 'active' : '' ?>" href="index.php?page=dashboard">▦ <span>Dashboard</span></a>
        <a class="nav-link <?= $page === 'sales' ? 'active' : '' ?>" href="index.php?page=sales">↗ <span>Sales Data</span></a>
        <a class="nav-link <?= $page === 'analytics' ? 'active' : '' ?>" href="index.php?page=analytics">◷ <span>Analytics</span></a>
        <a class="nav-link <?= $page === 'reports' ? 'active' : '' ?>" href="index.php?page=reports">▤ <span>Reports</span></a>
    </nav>
    <div class="sidebar-note">
        <strong>Project workspace</strong>
        <p>Starter prototype · v0.1</p>
    </div>
</aside>
