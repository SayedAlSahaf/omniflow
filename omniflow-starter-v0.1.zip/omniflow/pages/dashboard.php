<div class="topbar">
    <div>
        <p class="eyebrow">OVERVIEW</p>
        <h1>Dashboard</h1>
        <p class="muted mb-0">Your business performance, at a glance.</p>
    </div>
    <span class="date-chip">DEMO DATA · V0.1</span>
</div>

<section class="kpi-grid">
    <article class="kpi-card"><p>Total Revenue</p><h2>৳ 1,84,500</h2><span class="trend">↑ 12.8% <small>vs. last month</small></span></article>
    <article class="kpi-card"><p>Total Orders</p><h2>1,248</h2><span class="trend">↑ 8.2% <small>vs. last month</small></span></article>
    <article class="kpi-card"><p>Units Sold</p><h2>1,562</h2><span class="trend">↑ 6.4% <small>vs. last month</small></span></article>
    <article class="kpi-card"><p>Sales Channels</p><h2>4</h2><span class="neutral-trend">Website · Social · Store</span></article>
</section>

<section class="content-grid">
    <article class="panel chart-panel">
        <div class="panel-heading"><div><h3>Sales performance</h3><p>Monthly revenue overview</p></div><span class="select-label">Last 6 months</span></div>
        <div class="chart-wrap"><canvas id="salesChart" aria-label="Monthly sales performance chart"></canvas></div>
    </article>
    <article class="panel">
        <div class="panel-heading"><div><h3>Channel overview</h3><p>Revenue contribution</p></div></div>
        <div class="channel-row"><span class="channel-dot website"></span><span>Website</span><strong>৳ 82,500</strong></div>
        <div class="channel-row"><span class="channel-dot facebook"></span><span>Facebook</span><strong>৳ 54,000</strong></div>
        <div class="channel-row"><span class="channel-dot instagram"></span><span>Instagram</span><strong>৳ 31,000</strong></div>
        <div class="channel-row"><span class="channel-dot store"></span><span>Physical store</span><strong>৳ 17,000</strong></div>
        <p class="demo-note">Illustrative figures for interface testing.</p>
    </article>
</section>

<section class="panel table-panel">
    <div class="panel-heading"><div><h3>Recent sales</h3><p>Sample transactions from different channels</p></div><a href="index.php?page=sales" class="text-link">View all →</a></div>
    <div class="table-responsive">
        <table class="table align-middle">
            <thead><tr><th>REFERENCE</th><th>CHANNEL</th><th>DATE</th><th>AMOUNT</th><th>STATUS</th></tr></thead>
            <tbody>
                <tr><td>#OF-1008</td><td>Website</td><td>07 Nov 2026</td><td>৳ 1,450</td><td><span class="status complete">Completed</span></td></tr>
                <tr><td>#OF-1007</td><td>Facebook</td><td>07 Nov 2026</td><td>৳ 990</td><td><span class="status pending">Pending</span></td></tr>
                <tr><td>#OF-1006</td><td>Instagram</td><td>06 Nov 2026</td><td>৳ 2,100</td><td><span class="status complete">Completed</span></td></tr>
                <tr><td>#OF-1005</td><td>Physical store</td><td>06 Nov 2026</td><td>৳ 750</td><td><span class="status complete">Completed</span></td></tr>
            </tbody>
        </table>
    </div>
</section>
