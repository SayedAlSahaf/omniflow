-- OmniFlow starter database (MySQL 8+)
CREATE DATABASE IF NOT EXISTS omniflow
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE omniflow;

-- Sales-channel lookup table. More tables will be added after ERD approval.
CREATE TABLE IF NOT EXISTS sales_channels (
    channel_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    channel_name VARCHAR(80) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO sales_channels (channel_name)
VALUES ('Website'), ('Facebook'), ('Instagram'), ('WhatsApp'), ('Physical Store');

-- Placeholder for the normalized sales transaction model.
-- Final transaction, product and customer tables should follow the approved ERD.
